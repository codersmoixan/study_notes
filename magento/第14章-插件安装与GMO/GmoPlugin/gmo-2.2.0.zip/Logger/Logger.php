<?php
namespace Veriteworks\Gmo\Logger;

/**
 * Class Logger
 * @package Veriteworks\Gmo\Logger
 */
class Logger extends \Monolog\Logger
{
}
