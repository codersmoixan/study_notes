<?php
namespace Veriteworks\Gmo\Gateway\Adapter;

/**
 * Class Client
 * @package Veriteworks\Gmo\Gateway\Adapter
 */
class Client extends \Zend_Http_Client_Adapter_Curl
{

}
