<?php
namespace Veriteworks\Gmo\Model\Source;

/**
 * Payment action source
 */
class PaymentAction
{
    /**
     * @return array
     */
    public function toOptionArray()
    {
        return [
                [
                    'value' => 'authorize',
                    'label' => __('Authorize Only')
                    ],
                [
                    'value' => 'authorize_capture',
                    'label' => __('Authorize and Capture')
                    ]
                ];
    }
}
