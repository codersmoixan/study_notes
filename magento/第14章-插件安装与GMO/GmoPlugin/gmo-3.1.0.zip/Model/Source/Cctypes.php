<?php
namespace Veriteworks\Gmo\Model\Source;

/**
 * Available cc brands source
 */
class Cctypes
{
    /**
     * @return array
     */
    public function toOptionArray()
    {
        return [
                ['value' => 'VI','label' => __('Visa')],
                ['value' => 'MC','label' => __('Master Card')],
                ['value' => 'JCB','label' => __('JCB')],
                ['value' => 'AE','label' => __('American Express')],
                ['value' => 'DN','label' => __('Diners')]
                ];
    }
}
