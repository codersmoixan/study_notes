<?php
namespace Veriteworks\Gmo\Block\Form;

/**
 * Atm payment method form
 */
class Atm extends \Magento\Payment\Block\Form
{
    /**
     * @var string
     */
    protected $_template = 'Veriteworks_Gmo::form/atm.phtml';
}
