<?php
namespace Veriteworks\Gmo\Block\Form;

class Atm extends \Magento\Payment\Block\Form
{
    /**
     * @var string
     */
    protected $_template = 'Veriteworks_Gmo::form/atm.phtml';
}