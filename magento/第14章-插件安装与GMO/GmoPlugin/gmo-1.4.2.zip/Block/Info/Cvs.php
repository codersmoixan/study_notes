<?php
namespace Veriteworks\Gmo\Block\Info;

use \Magento\Framework\View\Element\Template\Context;
use \Veriteworks\Gmo\Model\Source\Cvstypes;

/**
 * Class Cvs
 * @package Veriteworks\Gmo\Block\Info
 */
class Cvs extends \Magento\Payment\Block\Info
{
    /**
     * @var string
     */
    protected $_template = 'Veriteworks_Gmo::info/cvs.phtml';

    /**
     * @var \Veriteworks\Gmo\Model\Source\Cvstypes
     */
    protected $_cvsTypes;

    /**
     * Cvs constructor.
     * @param \Magento\Framework\View\Element\Template\Context $context
     * @param \Veriteworks\Gmo\Model\Source\Cvstypes $cvstypes
     * @param array $data
     */
    public function __construct(
                                Context $context,
                                Cvstypes $cvstypes,
                                array $data = []
    )
    {
        parent::__construct($context, $data);
        $this->_cvsTypes = $cvstypes;
    }

    /**
     * @param null $transport
     * @return \Magento\Framework\DataObject
     */
    protected function _prepareSpecificInformation($transport = null)
    {
        if (null !== $this->_paymentSpecificInformation) {
            return $this->_paymentSpecificInformation;
        }
        $transport = parent::_prepareSpecificInformation($transport);
        $additional = unserialize($this->getInfo()->getAdditionalData());
        $data = array();

        if(is_array($additional)) {
            if (array_key_exists('Convenience', $additional)) {
                $source = $this->_cvsTypes;
                $data[__('CVS name')->__toString()] =
                    $source->getCvsType($additional['Convenience']);
            }

            if (array_key_exists('ConfNo', $additional)) {
                $data[__('Conf Number')->__toString()] = $additional['ConfNo'];
            }

            if (array_key_exists('ReceiptNo', $additional)) {
                $data[__('Receipt Number')->__toString()] = $additional['ReceiptNo'];
            }

            if (array_key_exists('PaymentTerm', $additional)) {
                $paydate = $additional['PaymentTerm'];
                $data[__('Payment limit date')->__toString()] =
                    preg_replace('/^(\d\d\d\d)(\d\d)(\d\d)(\d\d)(\d\d)(\d\d)$/',
                                 '$1/$2/$3 $4:$5:$6', $paydate);
            }

        }

        return $transport->setData(array_merge($transport->getData(), $data));
    }

}