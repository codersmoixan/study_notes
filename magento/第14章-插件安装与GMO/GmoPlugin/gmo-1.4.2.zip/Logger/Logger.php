<?php
namespace Veriteworks\Gmo\Logger;

class Logger extends \Monolog\Logger
{
}
