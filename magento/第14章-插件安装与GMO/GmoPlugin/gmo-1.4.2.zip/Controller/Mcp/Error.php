<?php
namespace Veriteworks\Gmo\Controller\Mcp;

use \Magento\Framework\App\Action\Action;

/**
 * Class Receive
 * @package Veriteworks\Gmo\Controller\Mcp
 */
class Error extends Action {
    /**
     * @var ScopeConfigInterface
     */
    protected $_scopeConfig;

    /**
     * @var \Magento\Checkout\Model\Session
     */
    protected $_session;

    /**
     * @var DataObjectFactory
     */
    protected $_dataObjectFactory;

    /**
     * @var \Magento\Sales\Api\OrderRepositoryInterface
     */
    protected $_orderRepository;

    /**
     * @var \Magento\Framework\Registry
     */
    protected $_coreRegistry;

    /**
     * @var \Psr\Log\LoggerInterface
     */
    protected $_logger;

    /**
     * @var \Magento\Quote\Api\CartRepositoryInterface
     */
    private $quoteRepository;


    /**
     * AbstractGmo constructor.
     * @param \Magento\Framework\App\Action\Context $context
     * @param \Magento\Framework\App\Config\ScopeConfigInterface $scopeConfig
     * @param \Magento\Checkout\Model\Session $checkoutSession
     * @param \Magento\Framework\DataObjectFactory $dataObjectFactory
     * @param \Magento\Framework\Registry $coreRegistry
     * @param \Magento\Sales\Api\OrderRepositoryInterface $orderRepository
     * @param \Psr\Log\LoggerInterface $logger
     * @param \Magento\Quote\Api\CartRepositoryInterface $quoteRepository
     */
    public function __construct(\Magento\Framework\App\Action\Context $context,
        \Magento\Framework\App\Config\ScopeConfigInterface $scopeConfig,
        \Magento\Checkout\Model\Session $checkoutSession,
        \Magento\Framework\DataObjectFactory $dataObjectFactory,
        \Magento\Framework\Registry $coreRegistry,
        \Magento\Sales\Api\OrderRepositoryInterface $orderRepository,
        \Psr\Log\LoggerInterface $logger,
        \Magento\Quote\Api\CartRepositoryInterface $quoteRepository
    )
    {
        parent::__construct($context);
        $this->_scopeConfig = $scopeConfig;
        $this->_session = $checkoutSession;
        $this->_dataObjectFactory = $dataObjectFactory;
        $this->_orderRepository = $orderRepository;
        $this->_coreRegistry = $coreRegistry;
        $this->_logger = $logger;
        $this->quoteRepository = $quoteRepository;
    }

    /**
     * redirect action
     */
    public function execute()
    {
        /** @var \Magento\Sales\Model\Order $order */
        $order = $this->_orderRepository->get($this->_session->getLastOrderId());
        $this->_logger->debug('LastOrderId ' .$this->_session->getLastOrderId());
        /** @var \Veriteworks\Gmo\Model\Method\Cc $method */
        $method = $order->getPayment()->getMethodInstance();
        $this->_coreRegistry->register('isSecureArea', true, true);

        if($method->receive3d($this->_request, $order)) {
            $this->_orderRepository->save($order);
            $this->_redirect('checkout/onepage/success');
        } else {
            $order->cancel();

            $quote = $this->quoteRepository->get($order->getQuoteId());
            $quote->setIsActive(1)->setReservedOrderId(null);
            $this->quoteRepository->save($quote);
            $this->_session->replaceQuote($quote)->unsLastRealOrderId();

            $message = __(
                'Unable to place order. Please try again later.'
            );
            $this->messageManager->addErrorMessage($message);
            //$this->_orderRepository->delete($order);
            $this->_redirect('checkout/cart');
        }
    }
}