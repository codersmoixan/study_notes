<?php
namespace Veriteworks\Gmo\Controller\Mcp;

use \Magento\Framework\App\Action\Action;

/**
 * Class Send
 * @package Veriteworks\Gmo\Controller\Mcp
 */
class Send extends Action {
    /**
     * @var ScopeConfigInterface
     */
    protected $_scopeConfig;

    /**
     * @var \Magento\Checkout\Model\Session
     */
    protected $_session;

    /**
     * @var DataObjectFactory
     */
    protected $_dataObjectFactory;

    /**
     * @var \Magento\Framework\Registry
     */
    protected $_coreRegistry;

    /**
     * @var \Psr\Log\LoggerInterface
     */
    protected $_logger;

    /**
     * @var \Magento\Sales\Api\OrderRepositoryInterface
     */
    protected $_orderRepository;


    /**
     * AbstractGmo constructor.
     * @param \Magento\Framework\App\Action\Context $context
     * @param \Magento\Framework\App\Config\ScopeConfigInterface $scopeConfig
     * @param \Magento\Checkout\Model\Session $checkoutSession
     * @param \Magento\Framework\DataObjectFactory $dataObjectFactory
     * @param \Magento\Framework\Registry $coreRegistry
     * @param \Magento\Sales\Api\OrderRepositoryInterface $orderRepository
     * @param \Psr\Log\LoggerInterface $logger
     */
    public function __construct(\Magento\Framework\App\Action\Context $context,
        \Magento\Framework\App\Config\ScopeConfigInterface $scopeConfig,
        \Magento\Checkout\Model\Session $checkoutSession,
        \Magento\Framework\DataObjectFactory $dataObjectFactory,
        \Magento\Framework\Registry $coreRegistry,
        \Magento\Sales\Api\OrderRepositoryInterface $orderRepository,
        \Psr\Log\LoggerInterface $logger
    )
    {
        parent::__construct($context);
        $this->_orderRepository = $orderRepository;
        $this->_scopeConfig = $scopeConfig;
        $this->_session = $checkoutSession;
        $this->_dataObjectFactory = $dataObjectFactory;
        $this->_coreRegistry = $coreRegistry;
        $this->_logger = $logger;
    }

    /**
     * redirect action
     */
    public function execute()
    {
        /** @var \Magento\Sales\Model\Order $order */
        $order = $this->_orderRepository->get($this->_session->getLastOrderId());
        $this->_logger->debug('LastOrderId ' .$this->_session->getLastOrderId());
        $method = $order->getPayment()->getMethod();

        //check this transaction is 3D secure or not.
        if ($this->_session->getCentinelUrl()) {
            $this->_view->loadLayout();
            $layout = $this->_view->getLayout();

            $block = $layout->getBlock('gmo_redirect');
            $this->_logger->debug(gettype($block));
            $this->_logger->debug($this->_request->getFullActionName());

            /** @var \Magento\Framework\DataObject $data */
            $data  = $this->_dataObjectFactory->create();

            $data->setAccessId($this->_session->getAccessId());
            $data->setToken($this->_session->getToken());
            $this->_logger->debug($method);

            $this->_logger->debug(var_export($data->toArray(), true));
            $block->setMcpData($data);
            $block->setDestUrl($this->_session->getCentinelUrl());

            $this->_view->renderLayout();
        } else {
            /** @var \Magento\Framework\Controller\Result\Redirect $resultRedirect */
            $resultRedirect = $this->resultRedirectFactory->create();
            return $resultRedirect->setPath('checkout/onepage/success');
        }
    }
}