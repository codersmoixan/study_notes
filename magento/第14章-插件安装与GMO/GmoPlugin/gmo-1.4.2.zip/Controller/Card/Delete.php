<?php
/**
 * NOTICE OF LICENSE
 *
 * This source file is subject to the Open Software License (OSL 3.0)
 * that is bundled with this package in the file LICENSE.txt.
 * It is also available through the world-wide-web at this URL:
 * http://opensource.org/licenses/osl-3.0.php
 * If you did not receive a copy of the license and are unable to
 * obtain it through the world-wide-web, please send an email
 * to info@veriteworks.co.jp so we can send you a copy immediately.
 *
 * @category
 * @package
 * @copyright  Copyright (c) $year Veriteworks Inc. (https://principle-works.jp/)
 * @license    http://opensource.org/licenses/osl-3.0.php  Open Software License (OSL 3.0)
 */

namespace Veriteworks\Gmo\Controller\Card;

use \Magento\Customer\Controller\AbstractAccount;
use Magento\Framework\App\Action\Context;
use Magento\Framework\View\Result\PageFactory;


class Delete extends AbstractAccount
{

    /**
     * @var PageFactory
     */
    protected $resultPageFactory;

    private $delete;

    /**
     * @param Context $context
     * @param \Veriteworks\Gmo\Model\Card\Delete $delete
     * @param PageFactory $resultPageFactory
     */
    public function __construct(
        Context $context,
        \Veriteworks\Gmo\Model\Card\Delete $delete,
        PageFactory $resultPageFactory
    ) {
        $this->resultPageFactory = $resultPageFactory;
        $this->delete = $delete;
        parent::__construct($context);
    }

    /**
     * Default customer account page
     *
     * @return \Magento\Framework\View\Result\Page
     */
    public function execute()
    {
        if(strtolower($this->_request->getMethod()) == 'post')
        {
            $this->_redirect('gmo/card/lists');
            return ;
        }

        try {
            $result = $this->delete->deleteCard($this->_request);
        } catch (Exception $e) {
            $this->messageManager->addErrorMessage(
                __('Failed to registering your card information.')
            );
        }

        $this->_redirect('gmo/card/lists');
    }
}