<?php
namespace Veriteworks\Gmo\Controller\Notify;

use \Magento\Framework\App\Action\Action;
use \Magento\Framework\App\Config\ScopeConfigInterface;
use \Magento\Store\Model\ScopeInterface;
use \Magento\Sales\Model\Order;
use \Magento\Sales\Model\Order\Email\Sender\InvoiceSender;
use Magento\Sales\Api\OrderManagementInterface as OrderManagement;

/**
 * Class Receive
 * @package Veriteworks\Gmo\Controller\Notify
 */
class Receive extends Action {
    /**
     * @var ScopeConfigInterface
     */
    protected $_scopeConfig;

    /**
     * @var \Magento\Checkout\Model\Session
     */
    protected $_session;

    /**
     * @var DataObjectFactory
     */
    protected $_dataObjectFactory;

    /**
     * @var \Magento\Framework\Registry
     */
    protected $_coreRegistry;

    /**
     * @var \Psr\Log\LoggerInterface
     */
    protected $_logger;

    /**
     * @var \Magento\Sales\Api\OrderRepositoryInterface
     */
    protected $_orderRepository;

    /**
     * @var \Magento\Sales\Model\Order\Email\Sender\InvoiceSender
     */
    protected $_invoiceSender;

    protected $orderFactory;


    /**
     * Receive constructor.
     * @param \Magento\Framework\App\Action\Context $context
     * @param \Magento\Framework\App\Config\ScopeConfigInterface $scopeConfig
     * @param \Magento\Checkout\Model\Session $checkoutSession
     * @param \Magento\Framework\DataObjectFactory $dataObjectFactory
     * @param \Magento\Framework\Registry $coreRegistry
     * @param \Magento\Sales\Api\OrderRepositoryInterface $orderRepository
     * @param \Magento\Sales\Model\OrderFactory $orderFactory
     * @param InvoiceSender $invoiceSender
     * @param \Psr\Log\LoggerInterface $logger
     */
    public function __construct(\Magento\Framework\App\Action\Context $context,
        \Magento\Framework\App\Config\ScopeConfigInterface $scopeConfig,
        \Magento\Checkout\Model\Session $checkoutSession,
        \Magento\Framework\DataObjectFactory $dataObjectFactory,
        \Magento\Framework\Registry $coreRegistry,
        \Magento\Sales\Api\OrderRepositoryInterface $orderRepository,
        \Magento\Sales\Model\OrderFactory $orderFactory,
        InvoiceSender $invoiceSender,
        \Psr\Log\LoggerInterface $logger
    )
    {
        parent::__construct($context);
        $this->_orderRepository = $orderRepository;
        $this->orderFactory = $orderFactory;
        $this->_scopeConfig = $scopeConfig;
        $this->_session = $checkoutSession;
        $this->_dataObjectFactory = $dataObjectFactory;
        $this->_coreRegistry = $coreRegistry;
        $this->_invoiceSender = $invoiceSender;
        $this->_logger = $logger;
    }

    /**
     * receive payment notify action
     */
    public function execute()
    {
        if (!$this->_request->isPost()) {
            $this->_response->setBody('1');
            return;
        }

        $payType = $this->_request->getParam('PayType');
        $shopId = $this->_request->getParam('ShopID');
        $shopPass = $this->_request->getParam('ShopPass');
        $orderId = $this->_request->getParam('OrderID');
        $status = $this->_request->getParam('Status');
        $this->_logger->debug(var_export($this->_request->getParams(), true));

        if (!$this->_chckShopID($shopId, $shopPass))
        {
            $this->_response->setBody('1');
            return;
        }

        /** @var \Magento\Sales\Model\Order $order */
        $order = $this->orderFactory->create()->loadByIncrementId($orderId);
        $this->_logger->debug('OrderId ' . $orderId);

        $method = $order->getPayment()->getMethodInstance();
        $this->_coreRegistry->register('isSecureArea', true, true);

        $dbStatus = $order->getState();

        if ($dbStatus === Order::STATE_NEW)
        {
            if ($status === "REQSUCCESS")
            {
                $order->addStatusHistoryComment(
                    __('Order was accepted successfully.'),
                    Order::STATE_PENDING_PAYMENT
                );
                $this->_orderRepository->save($order);
            } else if ($status === "PAYSUCCESS" && $order->canInvoice())
            {
                $invoice = $order->prepareInvoice();
                $invoice->register()->pay();
                $order->addRelatedObject($invoice);
                $orderState = Order::STATE_PROCESSING;
                $order->setState($orderState);
                $order->addStatusHistoryComment(
                    __('Order was payed successfully.'),
                    $orderState
                );
                $invoice->setSendEmail(true);
                $this->_orderRepository->save($order);
                $this->_invoiceSender->send($invoice);
            } else if ($status === "PAYFAIL" or $status === "EXPIRED")
            {
                $order->addStatusHistoryComment(
                    __('Order was expired or failed. ErrorCode:' . $status . '.'),
                    Order::STATE_CANCELED
                );
                $this->_orderRepository->save($order);
            }
        }

        $this->_response->setBody('0');
    }

    /**
     * @param $shopId
     * @param $shopPass
     * @return bool
     */
    protected function _chckShopID($shopId, $shopPass)
    {
        $confShopId = $this->_getConfig('shop_id');
        if ($shopId == $confShopId && $shopPass == '**********') {
            return true;
        }

        return false;
    }

    /**
     * @param $key
     * @return mixed
     */
    protected function _getConfig($key)
    {
        return $this->_scopeConfig->getValue('veritegmo/common/' . $key,
                                   ScopeInterface::SCOPE_STORE);
    }
}