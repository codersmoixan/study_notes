<?php
namespace Veriteworks\Gmo\Model\Config;

use Magento\Payment\Model\CcGenericConfigProvider;
use Magento\Payment\Helper\Data as PaymentHelper;
use Magento\Payment\Model\CcConfig;
use Veriteworks\Gmo\Model\Method\CcMulti;

class CcMultiProvider extends CcGenericConfigProvider
{
    const CODE = CcMulti::CODE;

    /**
     * ConfigProvider constructor.
     * @param Magento\Payment\Model\CcConfig; $ccConfig
     * @param \Magento\Payment\Helper\Data $paymentHelper
     * @param \Veriteworks\Gmo\Helper\Data $helper
     */
    public function __construct(
        CcConfig $ccConfig,
        PaymentHelper $paymentHelper,
        \Veriteworks\Gmo\Helper\Data $helper
    ){
        parent::__construct($ccConfig, $paymentHelper);
        $this->config = $helper;
    }
    /**
     * Retrieve assoc array of checkout configuration
     *
     * @return array
     */
    public function getConfig()
    {
        $config = parent::getConfig();
        $config = array_merge_recursive($config, [
            'payment' => [
                \Veriteworks\Gmo\Model\Method\CcMulti::CODE => [
                    'gateway_url' => $this->config->getGatewayUrl(),
                    'shop_id' => $this->config->getShopId(),
                    'use_token' => $this->config->getMultiUseToken()
                ]
            ]
        ]);

        return $config;
    }
}