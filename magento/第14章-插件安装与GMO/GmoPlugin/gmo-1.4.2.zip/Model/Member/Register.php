<?php
/**
 * NOTICE OF LICENSE
 *
 * This source file is subject to the Open Software License (OSL 3.0)
 * that is bundled with this package in the file LICENSE.txt.
 * It is also available through the world-wide-web at this URL:
 * http://opensource.org/licenses/osl-3.0.php
 * If you did not receive a copy of the license and are unable to
 * obtain it through the world-wide-web, please send an email
 * to info@veriteworks.co.jp so we can send you a copy immediately.
 *
 * @category
 * @package
 * @copyright  Copyright (c) $year Veriteworks Inc. (https://principle-works.jp/)
 * @license    http://opensource.org/licenses/osl-3.0.php  Open Software License (OSL 3.0)
 */

namespace Veriteworks\Gmo\Model\Member;

use \Magento\Customer\Helper\Session\CurrentCustomer;
use \Magento\Framework\Exception\LocalizedException;

class Register
{

    /**
     * @var \Veriteworks\Gmo\Gateway\ConnectorFactory
     */
    private $connectorFactory;

    /**
     * @var \Veriteworks\Gmo\Helper\Data
     */
    private $gmoHelper;

    /**
     * Search constructor.
     * @param \Veriteworks\Gmo\Gateway\ConnectorFactory $connectorFactory
     * @param \Veriteworks\Gmo\Helper\Data $gmoHelper
     */
    public function __construct(
        \Veriteworks\Gmo\Gateway\ConnectorFactory $connectorFactory,
        \Veriteworks\Gmo\Helper\Data $gmoHelper
    ) {
        $this->connectorFactory = $connectorFactory;
        $this->gmoHelper = $gmoHelper;
    }

    /**
     * @param CurrentCustomer $currentCustomer
     * @return bool
     * @throws \Veriteworks\Gmo\Model\Member\LocalizedException
     */
    public function execute(CurrentCustomer $currentCustomer)
    {
        $customer = $currentCustomer->getCustomer();
        $name = $customer->getLastname() . $customer->getFirstname();

        $obj = $this->connectorFactory->create();
        $obj->setApiPath('SaveMember');
        $obj->setParam('SiteID', $this->gmoHelper->getSiteId());
        $obj->setParam('SitePass', $this->gmoHelper->getSitePassword());
        $obj->setParam('MemberID', $customer->getId());
        $obj->setParam('MemberName', $name);

        $result = $obj->execute();

        return $this->_handleResponse($result);
    }

    /**
     * @param $response
     * @return bool
     * @throws \Veriteworks\Gmo\Model\Member\LocalizedException
     */
    private function _handleResponse($response)
    {
        if (array_key_exists('ErrCode', $response) &&
            $response['ErrCode'] == 'network error'
        ) {
            throw new LocalizedException(
                __('Could not access payment gateway server. Please retry again.')
            );
        } elseif (array_key_exists('ErrCode', $response)) {
            if (array_key_exists('ErrInfo', $response)
                && ($this->gmoHelper->isIgnore($response))
            ) {
                return false;
            } else {
                throw new LocalizedException(__('Registration error: %s .',
                    preg_replace('/\|/', ',', $response['ErrInfo'])));
            }
        }
        return true;
    }
}