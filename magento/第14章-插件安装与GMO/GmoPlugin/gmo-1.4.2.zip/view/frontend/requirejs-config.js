var config = {
    map: {
        '*': {
            deleteCard:            'Veriteworks_Gmo/deleteCard'
        }
    }
};

window.submitToGmo = function submitToGmo (response) {
    if( response.resultCode != '000' ){
        jQuery('#veritegmo_cc_cc_error').val(response.resultCode);
    }else {
        jQuery('#veritegmo_cc_cc_number').val('');
        jQuery('#veritegmo_cc_expiration').prop('selectedIndex', 0);
        jQuery('#veritegmo_cc_expiration_yr').prop('selectedIndex', 0);
        jQuery('#veritegmo_cc_cc_cid').val('');
        jQuery('#veritegmo_cc_cc_token').val(response.tokenObject.token);
    }
};

window.submitToGmoMulti = function submitToGmoMulti (response) {
    if( response.resultCode != '000' ){
        jQuery('#veritegmo_ccmulti_cc_error').val(response.resultCode);
    }else {
        jQuery('#veritegmo_ccmulti_cc_number').val('');
        jQuery('#veritegmo_ccmulti_expiration').prop('selectedIndex', 0);
        jQuery('#veritegmo_ccmulti_expiration_yr').prop('selectedIndex', 0);
        jQuery('#veritegmo_ccmulti_cc_cid').val('');
        jQuery('#veritegmo_ccmulti_cc_token').val(response.tokenObject.token);
    }
};
