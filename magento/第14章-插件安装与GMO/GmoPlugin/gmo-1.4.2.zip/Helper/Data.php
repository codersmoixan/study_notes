<?php
namespace Veriteworks\Gmo\Helper;

use \Magento\Store\Model\ScopeInterface;

class Data extends \Magento\Framework\App\Helper\AbstractHelper
{
    /**
     * @param \Magento\Framework\App\Helper\Context $context
     */
    public function __construct(
        \Magento\Framework\App\Helper\Context $context
    ) {
        parent::__construct($context);
    }

    /**
     * @param $response
     * @return bool
     */
    public function isRetryNeeded($response)
    {
        $errorCodes = explode('|', $response['ErrInfo']);
        $ignoreCodes = array('E01040010', 'E01240002', 'M01004010');
        //$noMemberCode = 'E01390002';
        foreach($ignoreCodes as $code) {
            if(in_array($code, $errorCodes)) {
                return true;
            }
        }

        return false;
    }

    /**
     * @param $response
     * @return bool
     */
    public function isIgnore($response)
    {
        $errorCodes = explode('|', $response['ErrInfo']);

        $noMemberCode = array('E01390002', 'E01240002');

        foreach($noMemberCode as $code) {
            if(in_array($code, $errorCodes)) {
                return true;
            }
        }


        return false;
    }

    /**
     * @return mixed
     */
    public function getShopId()
    {
        return $this->scopeConfig->
        getValue('veritegmo/common/shop_id', ScopeInterface::SCOPE_STORE);
    }

    /**
     * @return mixed
     */
    public function getShopPassword()
    {
        return $this->scopeConfig->
        getValue('veritegmo/common/shop_password', ScopeInterface::SCOPE_STORE);
    }

    /**
     * @return mixed
     */
    public function getSiteId()
    {
        return $this->scopeConfig->
        getValue('veritegmo/common/site_id', ScopeInterface::SCOPE_STORE);
    }

    /**
     * @return mixed
     */
    public function getSitePassword()
    {
        return $this->scopeConfig->
        getValue('veritegmo/common/site_password', ScopeInterface::SCOPE_STORE);
    }

    /**
     * @return mixed
     */
    public function getGatewayUrl()
    {
        return $this->scopeConfig->
        getValue('veritegmo/common/gateway_url', ScopeInterface::SCOPE_STORE);
    }

    /**
     * @return mixed
     */
    public function getPaymentType()
    {
        return $this->scopeConfig->
        getValue('payment/veritegmo_cc/payment_type', ScopeInterface::SCOPE_STORE);
    }

    /**
     * @return mixed
     */
    public function getSplitCount()
    {
        return $this->scopeConfig->
        getValue('payment/veritegmo_cc/split_count', ScopeInterface::SCOPE_STORE);
    }

    /**
     * @return mixed
     */
    public function getUseToken()
    {
        return $this->scopeConfig->
        getValue('payment/veritegmo_cc/use_token', ScopeInterface::SCOPE_STORE);
    }

    public function getMultiUseToken()
    {
        return $this->scopeConfig->
        getValue('payment/veritegmo_ccmulti/use_token', ScopeInterface::SCOPE_STORE);
    }

    /**
     * @return mixed
     */
    public function getRegisterCard()
    {
        return $this->scopeConfig->
        getValue('payment/veritegmo_cc/reg_active', ScopeInterface::SCOPE_STORE);
    }

}